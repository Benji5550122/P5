//credit to https://www.youtube.com/watch?v=o9sgjuh-CBM for transformations, angleMode and angle.
//credit tetronimoes from https://tetris.fandom.com/wiki/Category:Tetrominoes




let angle=0;

function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
}

function draw() {
  background(100);
  
  // title of the code
  
  fill(255);
  textSize(16);
  textAlign(CENTER,TOP);
  text('Tetris', 200, 5);
  
  
  
  //this is translation
  
  t(50,50);
  translate(150,150);

  // this is scaling and rotation
  
  s(.10);
  
   angle=angle + 1;
   translate(1000,1000)
 
  r(angle);
  translate(-1000,-1000)
  
    s(3.5)
  
  // these are the block pieces 
  
  iBlock();
  oBlock();
  zBlock();
  tBlock();
  lBlock();
}

function t(translateX,translateY){
  translate(translateX,translateY);
    rect(10,20,200,300);
  
}


function s(scaleAmount){

  scale(scaleAmount);
  
     // rect(10,20,200);
  
  
}

function r(rotateAmount){
   push();
  rotate(rotateAmount);
  
     rect(0,0,200);
  
  pop();
}

  function iBlock(){
    push();

  fill(0, 100, 255);
  rect(-50,-300,25,25)
  rect(-50,-325,25,25)
  rect(-50,-275,25,25)
  rect(-50,-250,25,25)
  pop();
  }
  
  function oBlock(){
  push();
  fill(255, 255, 0);
  rect(-200,-300,25,25)
  rect(-200,-325,25,25)
  rect(-225,-300,25,25)
  rect(-225,-325,25,25)
  pop();
  }
  
  function zBlock(){
    push();
  fill(255,0,0);
  rect(-275,-325,25,25)
  rect(-275,-300,25,25)
  rect(-300,-300,25,25)
  rect(-300,-275,25,25)
  pop();
  }

  function tBlock(){
      push();
  fill(255,0,255);
 rect(-150,-300,25,25)
  rect(-100,-300,25,25)
  rect(-125,-300,25,25)
  rect(-125,-325,25,25)
  pop();
  }
   
  function lBlock(){
    push();
  fill (0,255,0)
  rect(-5,-300,25,25)
  rect(-5,-325,25,25)
  rect(-5,-275,25,25)
  rect(20,-275,25,25)
  pop();
  }
  