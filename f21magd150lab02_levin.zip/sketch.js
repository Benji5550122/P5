function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0);
fill(150, 255 ,0)
circle(150, 250, 100, 75)
  
fill (0, 0, 255)
circle(70, 100, 70, 100)
  
fill (200, 100 , 100)
circle(300, 100, 150, 100)
  
fill (255)
  circle(150 , 100, 5, 5)
  circle(10,300, 5, 5)
   circle(100,380, 5, 5)
   circle(200,350, 5, 5)
  circle(300, 250, 5, 5)
   circle(50,200, 5, 5)
}