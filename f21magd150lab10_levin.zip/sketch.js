//Credit:  most code from reference material
//Credit: models from Tinkercad.com
//Credit: camera from https://editor.p5js.org/owenroberts/sketches/BJgRAoaJV
//Credit: csv loadTable from https://p5js.org/reference/#/p5/loadTable
// draw an ellipsoid
// with radius 30, 40 and 40.

let table;

function setup() {
  createCanvas(500, 500, WEBGL);
  
  //prints names of the objects on the console
  
  
  for (let r = 0; r < table.getRowCount(); r++)
    for (let c = 0; c < table.getColumnCount(); c++) {
      print(table.getString(r, c));
    }
}
//sets up camera and lighting


function draw() {
  background(200);
  
	var x = map(mouseX, 0, width, -100, 100);
	var y = map(mouseY, 0, height, -100, 100);
	camera(0, 0, 200, x, y, 0, 0, 1, 0);
   ambientLight(100); // white light
  ambientMaterial(255, 102, 94); // magenta material
  rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.01);
  translate(-150,0,0)
  normalMaterial();
    ellipsoid(30, 40, 40);
  translate(150,0,0)
  ambientLight(60);
  
  //loads the models in
  
   model(rocketman);
    translate(150,0,0)
  ambientLight(0);
  emissiveMaterial(130, 230, 0);
  cylinder(20, 100);
 translate(-150,-150,0)
  ambientLight(200);
  ambientMaterial(70, 130, 230);
    //move your mouse to change light direction of tree
  let dirX = (mouseX / width - 0.5) * 2;
  let dirY = (mouseY / height - 0.5) * 2;
  directionalLight(250, 250, 250, -dirX, -dirY, -1);
  noStroke();
   model(tree);

}

//the models

function preload() {
  rocketman = loadModel('assets/tinker.obj', true);
  tree = loadModel('assets/tree.obj',true);
  table = loadTable('assets/objects.csv', 'csv', 'header');
}