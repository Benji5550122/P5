// Credit video from https://www.pexels.com/video/a-dog-fights-with-his-reflection-in-the-mirror-3042473/
// Credit sound from https://downloads.khinsider.com/game-soundtracks/album/super-mario-bros/01%2520-%2520Super%2520Mario%2520Bros.mp3
//Credit sound code adapted from https://p5js.org/reference/#/p5.SoundFile/loop
//Credit video code adapted from https://p5js.org/reference/#/p5/createVideo
// Credit playback rate code adapted from https://p5js.org/reference/#/p5.SoundFile/rate


let video;
let marioSoundFile;

function setup() {

  let cnv = createCanvas(200, 150);
 
  cnv.mousePressed(canvasPressed);
  
  video = createVideo(['assets/video.mp4'], videoLoad );

  video.size(150, 150);
  
}

// This function is called when the video loads
function videoLoad() {
  video.position(200,250);
  video.loop();
  video.volume(0);
}
// creates the text box and controls for adjusting pitch/pausing sound

function draw() {
  background(220);
  text('click to play,\n\nhold click to pause,\n\nmove the mouse up and down in this box to change the playback rate', 10, 20, width - 20);
  
// displays the change in playback rate depending on mouse movement
  
  let playbackRate = map(mouseY, 0.1, height, 2, 0);
  playbackRate = constrain(playbackRate, 0.01, 4);
  marioSoundFile.rate(playbackRate);

  line(0, mouseY, width, mouseY);
  text('playback rate: ' + round(playbackRate * 100) + '%', 20, 140);
}
// loads in the Mario music sound file

function preload() {
  soundFormats('mp3');
  marioSoundFile = loadSound('assets/mario');
}

function canvasPressed() {
 marioSoundFile.pause();
 
  
 
}
function mouseReleased() {
   
   marioSoundFile.loop();
}