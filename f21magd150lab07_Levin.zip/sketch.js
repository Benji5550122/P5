// Credit -- load images from https://happycoding.io/tutorials/p5js/images
//image credit https://pngtree.com/so/Autumn  and  'https://pngtree.com/so/yellow'
// classes made by watching tutorial https://youtu.be/rHiSsgFRgx4

function setup() {
  createCanvas(400, 400);
  leaf1 = new Leaf(25,0,80,40);
  leaf2 = new Leaf(300,0,80,40);
  leaf3 = new Leaf(25,350,80,40);
  leaf4 = new Leaf(300,350,80,40);
  
  tree1 = new Tree(0,150,200,100);
  tree2 = new Tree(200,150,200,100);
}

function draw() {
  background(220);
  leaf1.showLeaf();
  leaf2.showLeaf();
  leaf3.showLeaf();
  leaf4.showLeaf();
  
  tree1.showTree();
  tree2.showTree();
    

}

function preload(){
  treeImage =loadImage("images/tree.png")
  leafImage =loadImage("images/leaf.png")
}

class Leaf{
  constructor(x,y,w,h){
    this.x = x;
    this.y = y;
    this.width = w;
    this.height = h;
    
    
  }
  
  showLeaf(){
    image(leafImage,this.x,this.y,this.width,this.height);
}
}  
  
class Tree{
  
  constructor(x,y,w,h){
    this.x = x;
    this.y = y;
    this.width = w;
    this.height = h;
   
  }
  
    showTree(){
    image(treeImage,this.x,this.y,this.width,this.height);
}
}