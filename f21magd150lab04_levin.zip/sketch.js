function setup() {
  createCanvas(400, 400);
  x=0;
}

function draw() {
     frameRate(60);
  x=x+1;
  if(x<200){
   
     background(200);
    fill(200,170,150);
    ellipse(x, 200, 250, 250);
    fill(255, 255, 0);
     ellipse(x,200,220,220);
  }
  fill(50);
  textSize(16);
  textAlign(CENTER,TOP);
  text('Pizza Time', 200, 30);
text ('click to add pepperoni', 200, 350)
  text ('hold any key for mushrooms', 200,375)
  if (keyIsPressed) {
    fill(250)
    ellipse(mouseX, mouseY, 10, 20);
  }
  if (mouseIsPressed) {
    fill(255,0,0)
    ellipse(mouseX, mouseY, 30, 30);
  }
}