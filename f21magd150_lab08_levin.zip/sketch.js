// credit fonts from https://github.com/googlefonts/
// credit images from https://www.pngwing.com/en/free-png-btgnz and https://www.pngwing.com/en/free-png-nyhih
// credit rotate from http://learningprocessing.com/examples/chp17/example-17-05-rotatetext

angle=0;


function setup() {
  createCanvas(400, 400);
 
}



function draw() {
  background(220);
  
  //changes color and opacity of images and text
  
  tint(255, 255); 
  image(frodo,260,260,110,110);
  
  noTint();
  
  gollum.filter(GRAY); //gray filter
  image(gollum,1,300,100,100);

  
  fill(255,230,0);
  textFont(font1);
  textSize(36);
  textAlign(LEFT);
  text(textFile[0], 50, 40);
  textFont(font2);
  textSize(20);
  
  textAlign(CENTER);
  push();
  translate(width/2, height/2);
  rotate(angle);                
 text(textFile[1], 0, 0); 
  pop();

 
  angle += 0.02;
}

//loads png and txt files into the code

function preload(){
  textFile = loadStrings("strings.txt");
  frodo =loadImage("images/frodo2.png");
  gollum = loadImage("images/gollum.png");
  gollum2 = loadImage("images/gollum.png");
  font1 = loadFont('assets/Inconsolata-Black.otf');
 font2 = loadFont("assets/Montserrat-Black.otf");
 
}
